package com.example.anatomymaster

import android.os.Bundle
import android.content.Context
import android.content.SharedPreferences
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Topic(val title: String, val region: String, val facts: List<String>, val clinical: String)
data class MCQ(val question: String, val options: List<String>, val answer: Int, val explanation: String)

val topics = listOf(
    Topic("Brachial Plexus", "Upper Limb", listOf(
        "Roots: C5–T1 anterior rami.",
        "Trunks: superior, middle and inferior.",
        "Divisions: anterior and posterior.",
        "Cords are named in relation to the second part of the axillary artery.",
        "Terminal branches include musculocutaneous, median, ulnar, axillary and radial nerves."
    ), "Upper trunk lesions can produce Erb-type palsy; lower trunk lesions may affect intrinsic hand function."),
    Topic("Median Nerve", "Upper Limb", listOf(
        "Formed by lateral and medial roots of the brachial plexus.",
        "Travels with the brachial artery in the arm.",
        "Passes through the cubital fossa and between heads of pronator teres.",
        "Enters the hand through the carpal tunnel.",
        "Supplies most anterior forearm muscles and thenar muscles via recurrent branch, with important exceptions."
    ), "Carpal tunnel syndrome may cause pain/paresthesia in the lateral 3½ digits and weakness of thenar function."),
    Topic("Biceps Brachii", "Upper Limb", listOf(
        "Long head arises from supraglenoid tubercle; short head from coracoid process.",
        "Inserts mainly on radial tuberosity and bicipital aponeurosis.",
        "Powerful supinator when the elbow is flexed.",
        "Also flexes the elbow.",
        "Musculocutaneous nerve supplies it."
    ), "Biceps tendon reflex tests mainly C5–C6 via the musculocutaneous nerve."),
    Topic("Femoral Nerve", "Lower Limb", listOf(
        "Roots: L2–L4 posterior divisions.",
        "Passes between psoas major and iliacus, then under the inguinal ligament.",
        "Motor supply includes quadriceps femoris.",
        "Provides sensory supply to anterior thigh and medial leg through the saphenous nerve.",
        "It lies lateral to the femoral artery in the femoral triangle."
    ), "Femoral nerve injury can weaken knee extension and reduce the patellar reflex."),
    Topic("Sciatic Nerve", "Lower Limb", listOf(
        "Largest peripheral nerve in the body.",
        "Roots: L4–S3.",
        "Leaves pelvis through greater sciatic foramen, usually inferior to piriformis.",
        "Divides into tibial and common fibular components.",
        "Supplies the hamstrings and, through its branches, most of the leg and foot."
    ), "Posterior hip dislocation can injure the sciatic nerve."),
    Topic("Thoracic Wall", "Thorax", listOf(
        "Typical intercostal nerves are anterior rami of T1–T11.",
        "Intercostal neurovascular bundles run in the costal groove.",
        "The main bundle is arranged VAN: vein, artery, nerve.",
        "Internal intercostal muscles assist forced expiration.",
        "External intercostal muscles assist inspiration."
    ), "Procedures involving the intercostal space are placed close to the superior border of the rib to reduce risk to the main neurovascular bundle."),
    Topic("Lungs", "Thorax", listOf(
        "Right lung normally has three lobes.",
        "Left lung normally has two lobes and a lingula.",
        "Oblique fissure occurs in both lungs.",
        "Horizontal fissure is a feature of the right lung.",
        "The hilum transmits bronchi, pulmonary vessels, lymphatics and nerves."
    ), "Aspirated material commonly follows the more vertical/right-sided bronchial pathway depending on body position."),
    Topic("Heart", "Thorax", listOf(
        "Right atrium receives systemic venous blood.",
        "Right ventricle pumps blood into pulmonary circulation.",
        "Left atrium receives pulmonary venous blood.",
        "Left ventricle pumps blood into systemic circulation.",
        "The apex is formed mainly by the left ventricle."
    ), "The cardiac apex is normally located in the left 5th intercostal space near the midclavicular line."),
    Topic("Abdominal Aorta", "Abdomen", listOf(
        "Begins at the aortic hiatus around T12.",
        "Ends by bifurcating into common iliac arteries around L4.",
        "Unpaired major branches include celiac trunk, superior mesenteric and inferior mesenteric arteries.",
        "Paired branches include renal and gonadal arteries.",
        "Lumbar arteries supply the posterior abdominal wall."
    ), "The aortic bifurcation level is clinically relevant during vascular imaging and procedures."),
    Topic("Inguinal Canal", "Abdomen", listOf(
        "An oblique passage through the lower anterior abdominal wall.",
        "Transmits the spermatic cord in males and round ligament of uterus in females.",
        "The ilioinguinal nerve passes through part of the canal but does not enter through the deep inguinal ring.",
        "Deep ring is an opening in transversalis fascia.",
        "Superficial ring is an opening in external oblique aponeurosis."
    ), "Inguinal hernias are classified as indirect or direct according to their relationship to the inferior epigastric vessels."),
    Topic("Cranial Nerves", "Head & Neck", listOf(
        "There are 12 pairs of cranial nerves.",
        "CN I is olfactory; CN II optic.",
        "CN III, IV and VI control most extraocular movements.",
        "CN V is the major sensory nerve of the face and motor nerve to muscles of mastication.",
        "CN VII supplies muscles of facial expression."
    ), "A facial nerve lesion can produce weakness of muscles of facial expression on the affected side."),
    Topic("Cavernous Sinus", "Head & Neck", listOf(
        "Located on either side of the body of the sphenoid.",
        "Internal carotid artery and CN VI pass through the sinus.",
        "CN III, IV, V1 and V2 are related to its lateral wall.",
        "It communicates with facial and orbital venous pathways.",
        "Infection can spread to it from facial/orbital regions."
    ), "Cavernous sinus thrombosis can affect ocular movements and facial sensation."),
    Topic("Pelvic Floor", "Pelvis & Perineum", listOf(
        "Levator ani is a major component of the pelvic diaphragm.",
        "Pelvic floor supports pelvic viscera.",
        "Pudendal nerve is the main somatic nerve of the perineum.",
        "Internal pudendal vessels accompany the pudendal nerve in the pudendal canal.",
        "Pelvic floor function contributes to continence."
    ), "Pelvic floor injury or dysfunction can contribute to pelvic organ support problems and continence disorders."),
    Topic("Spinal Cord", "Neuroanatomy", listOf(
        "Extends from the medulla to approximately L1–L2 in the adult.",
        "Cervical and lumbosacral enlargements relate to limb innervation.",
        "Dorsal roots carry sensory afferents.",
        "Ventral roots carry motor efferents.",
        "Spinal nerves form from dorsal and ventral roots."
    ), "The conus medullaris usually ends around L1–L2 in adults, but the exact level varies."),
    Topic("Bone Landmarks", "Bones & Joints", listOf(
        "The scapular spine continues laterally as the acromion.",
        "The humeral surgical neck is clinically important because of the axillary nerve.",
        "The radial head participates in the elbow joint.",
        "The femoral neck is a common site of fracture in older adults.",
        "The medial malleolus is part of the tibia."
    ), "Fractures around the surgical neck of the humerus may threaten the axillary nerve and posterior circumflex humeral vessels.")
)

val mcqs = listOf(
    MCQ("The roots of the brachial plexus are:", listOf("C3–C7","C5–T1","T1–T5","L1–L4"),1,"The brachial plexus is formed by anterior rami C5–T1."),
    MCQ("The median nerve enters the hand through the:", listOf("Cubital tunnel","Guyon canal","Carpal tunnel","Adductor canal"),2,"The median nerve passes beneath the flexor retinaculum in the carpal tunnel."),
    MCQ("The main action of biceps brachii when the elbow is flexed is:", listOf("Pronation","Supination","Wrist extension","Finger flexion"),1,"Biceps is a powerful forearm supinator, especially with the elbow flexed."),
    MCQ("The femoral nerve roots are mainly:", listOf("C2–C4","C5–T1","L2–L4","S1–S3"),2,"The femoral nerve is derived from posterior divisions of L2–L4."),
    MCQ("The sciatic nerve roots are:", listOf("L1–L3","L4–S3","S1–S5","C5–T1"),1,"The sciatic nerve contains fibers from L4 through S3."),
    MCQ("The main intercostal neurovascular bundle is arranged:", listOf("NAV","VAN","AVN","NVA"),1,"In the costal groove, the classic superior-to-inferior order is vein, artery, nerve."),
    MCQ("Which lung has a horizontal fissure?", listOf("Left","Right","Both","Neither"),1,"The right lung has horizontal and oblique fissures."),
    MCQ("The apex of the heart is formed mainly by the:", listOf("Right atrium","Right ventricle","Left atrium","Left ventricle"),3,"The apex is formed mainly by the left ventricle."),
    MCQ("The abdominal aorta usually bifurcates near:", listOf("T10","T12","L2","L4"),3,"The common teaching landmark is approximately L4."),
    MCQ("The ilioinguinal nerve:", listOf("Enters through the deep ring","Passes through part of the inguinal canal","Is a branch of femoral nerve","Is a cranial nerve"),1,"It enters the canal by piercing the abdominal wall and exits via the superficial ring."),
    MCQ("CN V is the major sensory nerve of the:", listOf("Face","Lower limb","Thorax","Pelvis"),0,"The trigeminal nerve provides the major general sensory supply of the face."),
    MCQ("Which cranial nerve passes through the cavernous sinus alongside the internal carotid artery?", listOf("CN II","CN V","CN VI","CN XII"),2,"CN VI runs within the cavernous sinus beside the internal carotid artery."),
    MCQ("The main somatic nerve of the perineum is the:", listOf("Femoral","Pudendal","Sciatic","Obturator"),1,"The pudendal nerve supplies major somatic motor and sensory functions in the perineum."),
    MCQ("In adults, the spinal cord usually ends around:", listOf("T6","T12","L1–L2","S3"),2,"The conus medullaris usually ends around L1–L2 in adults."),
    MCQ("A fracture of the surgical neck of the humerus may injure the:", listOf("Median nerve","Ulnar nerve","Axillary nerve","Musculocutaneous nerve"),2,"The axillary nerve winds around the surgical neck with the posterior circumflex humeral artery.")
)


val extraMcqs = listOf(
    MCQ("Which cord gives rise to the ulnar nerve?", listOf("Lateral","Medial","Posterior","Superior"),1,"The ulnar nerve is a terminal branch of the medial cord."),
    MCQ("The musculocutaneous nerve mainly supplies muscles of the:", listOf("Posterior arm","Anterior arm","Posterior forearm","Hand"),1,"It supplies the anterior compartment of the arm."),
    MCQ("The radial nerve is the major nerve of the:", listOf("Anterior arm","Posterior arm and forearm","Thenar compartment","Medial thigh"),1,"The radial nerve supplies the posterior compartments of the upper limb."),
    MCQ("Which nerve passes behind the medial epicondyle?", listOf("Median","Radial","Ulnar","Axillary"),2,"The ulnar nerve is palpable behind the medial epicondyle."),
    MCQ("The axillary nerve accompanies the:", listOf("Superior ulnar collateral artery","Posterior circumflex humeral artery","Brachial artery","Radial artery"),1,"Both pass around the surgical neck of the humerus."),
    MCQ("The deltoid muscle is primarily supplied by the:", listOf("Axillary nerve","Radial nerve","Median nerve","Ulnar nerve"),0,"The axillary nerve supplies deltoid and teres minor."),
    MCQ("The carpal tunnel contains the median nerve and:", listOf("Flexor tendons","Ulnar nerve","Radial artery","Ulnar artery"),0,"The tunnel contains the median nerve and flexor tendons."),
    MCQ("The ulnar nerve enters the hand superficial to the:", listOf("Flexor retinaculum","Extensor retinaculum","Palmar aponeurosis","Biceps tendon"),0,"It passes through Guyon canal superficial to the flexor retinaculum."),
    MCQ("The anatomical snuffbox is related to the:", listOf("Ulnar artery","Radial artery","Brachial artery","Axillary artery"),1,"The radial artery crosses the floor of the anatomical snuffbox."),
    MCQ("The main artery of the arm is the:", listOf("Brachial artery","Radial artery","Ulnar artery","Axillary vein"),0,"The brachial artery continues from the axillary artery."),
    MCQ("The femoral triangle contains the femoral nerve, artery, vein and:", listOf("Lymphatics","Sciatic nerve","Obturator nerve","Tibial nerve"),0,"The femoral triangle contains major vessels, femoral nerve and lymphatics."),
    MCQ("The femoral artery is the continuation of the:", listOf("External iliac artery","Internal iliac artery","Popliteal artery","Deep femoral artery"),0,"It becomes the femoral artery after passing deep to the inguinal ligament."),
    MCQ("The great saphenous vein passes anterior to the:", listOf("Lateral malleolus","Medial malleolus","Fibular head","Patella"),1,"It passes anterior to the medial malleolus."),
    MCQ("The small saphenous vein passes posterior to the:", listOf("Medial malleolus","Lateral malleolus","Tibial tuberosity","Patella"),1,"It passes posterior to the lateral malleolus."),
    MCQ("The common fibular nerve winds around the:", listOf("Medial epicondyle","Head of fibula","Femoral neck","Tibial tuberosity"),1,"It is vulnerable near the fibular neck."),
    MCQ("The tibial nerve is the major nerve of the:", listOf("Anterior leg","Posterior leg","Anterior thigh","Dorsum of foot"),1,"It supplies the posterior compartment of the leg."),
    MCQ("The obturator nerve mainly supplies the:", listOf("Adductors of thigh","Quadriceps","Hamstrings","Gluteal muscles"),0,"It supplies most muscles of the medial thigh."),
    MCQ("The gluteus maximus is supplied by the:", listOf("Superior gluteal nerve","Inferior gluteal nerve","Femoral nerve","Obturator nerve"),1,"The inferior gluteal nerve supplies gluteus maximus."),
    MCQ("The superior gluteal nerve supplies:", listOf("Gluteus maximus only","Gluteus medius, minimus and TFL","Piriformis only","Hamstrings"),1,"It supplies the main abductors of the hip."),
    MCQ("The patellar ligament is a continuation of the:", listOf("Quadriceps tendon","Hamstring tendon","Iliotibial tract","Achilles tendon"),0,"It continues from the quadriceps tendon around the patella."),
    MCQ("The diaphragm is mainly supplied motorically by the:", listOf("Vagus nerve","Phrenic nerve","Intercostal nerves","Sympathetic trunk"),1,"The phrenic nerves carry motor fibers to the diaphragm."),
    MCQ("The phrenic nerve roots are:", listOf("C1–C3","C3–C5","C5–C7","T1–T3"),1,"The classic mnemonic is C3, 4, 5 keep the diaphragm alive."),
    MCQ("The trachea bifurcates at approximately the:", listOf("Sternal angle","Xiphisternal joint","Jugular notch","T12 level"),0,"The carina is near the sternal angle, around T4/T5."),
    MCQ("The sternal angle corresponds approximately to:", listOf("T1/T2","T4/T5","T8/T9","L1/L2"),1,"It is a major surface landmark at the T4/T5 level."),
    MCQ("The left recurrent laryngeal nerve loops under the:", listOf("Subclavian artery","Aortic arch","Pulmonary trunk","Common carotid artery"),1,"It loops under the aortic arch near the ligamentum arteriosum."),
    MCQ("The right recurrent laryngeal nerve loops under the:", listOf("Aortic arch","Right subclavian artery","Pulmonary artery","Internal carotid artery"),1,"It loops around the right subclavian artery."),
    MCQ("The SA node is usually supplied by a branch of the:", listOf("Right coronary artery","Left anterior descending artery","Circumflex artery","Pulmonary artery"),0,"Most commonly it is supplied by the RCA, though variation exists."),
    MCQ("The AV node is located in the:", listOf("Left atrium","Right atrium","Left ventricle","Interventricular septum apex"),1,"It is in the right atrial region near the interatrial septum."),
    MCQ("The celiac trunk mainly supplies:", listOf("Foregut derivatives","Midgut derivatives","Hindgut derivatives","Pelvic organs"),0,"Its branches supply abdominal foregut structures."),
    MCQ("The superior mesenteric artery mainly supplies:", listOf("Foregut","Midgut","Hindgut","Kidney"),1,"It supplies the midgut and its derivatives."),
    MCQ("The inferior mesenteric artery mainly supplies:", listOf("Foregut","Midgut","Hindgut","Liver"),2,"It supplies the hindgut and its derivatives."),
    MCQ("The portal vein is formed mainly by the union of the:", listOf("Splenic and superior mesenteric veins","Inferior and superior vena cava","Renal veins","Hepatic veins"),0,"The splenic vein joins the SMV behind the neck of the pancreas."),
    MCQ("The portal triad contains the portal vein, hepatic artery and:", listOf("Hepatic vein","Bile duct","Splenic artery","IVC"),1,"These structures travel in the hepatoduodenal ligament."),
    MCQ("The appendix is typically located at the junction of the:", listOf("Jejunum and ileum","Ileum and cecum","Colon and rectum","Duodenum and jejunum"),1,"It arises from the cecum near the ileocecal region."),
    MCQ("McBurney point is classically related to the:", listOf("Appendix","Gallbladder","Pancreas","Spleen"),0,"It is a surface landmark associated with appendiceal tenderness."),
    MCQ("The kidneys are primarily:", listOf("Intraperitoneal","Retroperitoneal","Subcutaneous","Intrapleural"),1,"The kidneys are retroperitoneal organs."),
    MCQ("The right kidney is usually lower because of the:", listOf("Spleen","Liver","Heart","Stomach"),1,"The large liver occupies space superior to the right kidney."),
    MCQ("The pituitary gland lies in the:", listOf("Foramen magnum","Sella turcica","Orbit","Cavernous sinus lumen"),1,"It occupies the hypophyseal fossa of the sella turcica."),
    MCQ("The optic nerve passes through the:", listOf("Superior orbital fissure","Optic canal","Foramen rotundum","Jugular foramen"),1,"CN II travels through the optic canal."),
    MCQ("CN III supplies most:", listOf("Extraocular muscles","Facial muscles","Masticatory muscles","Pharyngeal muscles"),0,"Oculomotor supplies most extraocular muscles and levator palpebrae."),
    MCQ("CN IV supplies the:", listOf("Superior oblique","Lateral rectus","Medial rectus","Inferior oblique"),0,"Trochlear nerve supplies superior oblique."),
    MCQ("CN VI supplies the:", listOf("Superior rectus","Lateral rectus","Inferior rectus","Superior oblique"),1,"Abducens nerve supplies lateral rectus."),
    MCQ("The facial nerve exits the skull through the:", listOf("Internal acoustic meatus and stylomastoid foramen","Foramen ovale","Jugular foramen","Optic canal"),0,"It enters the facial canal via the internal acoustic meatus and exits via stylomastoid foramen."),
    MCQ("The vagus nerve exits the skull through the:", listOf("Jugular foramen","Foramen rotundum","Optic canal","Hypoglossal canal"),0,"CN X exits through the jugular foramen."),
    MCQ("The hypoglossal nerve supplies the:", listOf("Tongue muscles","Facial expression","Mastication","Pharyngeal constrictors"),0,"CN XII is the motor nerve to most tongue muscles."),
    MCQ("The internal jugular vein is a continuation of the:", listOf("Sigmoid sinus","Superior sagittal sinus","Straight sinus","Cavernous sinus only"),0,"It begins as a continuation of the sigmoid sinus at the jugular foramen."),
    MCQ("The carotid sheath contains the common/internal carotid artery, internal jugular vein and:", listOf("Phrenic nerve","Vagus nerve","Hypoglossal nerve","Sympathetic chain"),1,"The vagus nerve lies between and posterior to the artery and vein."),
    MCQ("The thyroid gland is closely related posteriorly to the:", listOf("Parathyroid glands","Pituitary gland","Spleen","Thymus only"),0,"Parathyroid glands are commonly located on the posterior surface of the thyroid."),
    MCQ("The pelvic diaphragm is formed mainly by:", listOf("Levator ani and coccygeus","Piriformis and obturator internus","Gluteus maximus and medius","Rectus abdominis"),0,"Levator ani and coccygeus form the pelvic diaphragm."),
    MCQ("The pudendal nerve roots are:", listOf("L1–L2","L2–L4","S2–S4","S4–Co1"),2,"Pudendal nerve arises from S2–S4."),
    MCQ("The sacral plexus is mainly formed by:", listOf("L1–L4","L4–S4","S1–Co1","T12–L2"),1,"The lumbosacral trunk and anterior rami S1–S4 form the sacral plexus."),
    MCQ("Dorsal roots of spinal nerves carry:", listOf("Motor fibers","Sensory fibers","Only sympathetic fibers","Only parasympathetic fibers"),1,"Dorsal roots carry afferent sensory fibers."),
    MCQ("Ventral roots of spinal nerves carry:", listOf("Sensory fibers only","Motor efferent fibers","Visual fibers","Olfactory fibers"),1,"Ventral roots carry motor efferents."),
    MCQ("The dorsal root ganglion contains cell bodies of:", listOf("Somatic sensory neurons","Motor neurons","Cerebellar neurons","Autonomic effector cells"),0,"It contains cell bodies of primary sensory neurons."),
    MCQ("The corpus callosum connects:", listOf("The two cerebral hemispheres","Cerebrum and cerebellum","Medulla and pons","Spinal cord and brainstem"),0,"It is the major commissural connection between cerebral hemispheres."),
    MCQ("The cerebellum is primarily involved in:", listOf("Coordination of movement","Vision only","Hearing only","Endocrine secretion"),0,"It coordinates movement and contributes to balance and motor learning."),
    MCQ("The femoral neck is clinically important because fracture may threaten the:", listOf("Retinacular blood supply to femoral head","Radial artery","Axillary nerve","Ulnar nerve"),0,"Femoral head blood supply can be compromised after intracapsular fractures."),
    MCQ("The medial malleolus belongs to the:", listOf("Fibula","Tibia","Talus","Calcaneus"),1,"It is the distal projection of the tibia."),
    MCQ("The lateral malleolus belongs to the:", listOf("Tibia","Fibula","Talus","Navicular"),1,"It is the distal projection of the fibula."),
    MCQ("The acetabulum articulates with the:", listOf("Head of femur","Head of humerus","Tibial plateau","Talus"),0,"It forms the hip joint with the femoral head."),
    MCQ("The glenoid cavity articulates with the:", listOf("Head of femur","Head of humerus","Radius","Ulna"),1,"It forms the glenohumeral joint with the humeral head.")
)



data class ImageQuestion(
    val structure: String,
    val clue: String,
    val options: List<String>,
    val answer: Int
)


data class Flashcard(val front: String, val back: String, val region: String)

val flashcards = listOf(
    Flashcard("Brachial plexus roots?", "C5–T1 anterior rami.", "Upper Limb"),
    Flashcard("Median nerve: terminal passage into hand?", "Carpal tunnel.", "Upper Limb"),
    Flashcard("Biceps: main actions?", "Elbow flexion and forearm supination.", "Upper Limb"),
    Flashcard("Ulnar nerve: landmark?", "Passes posterior to the medial epicondyle.", "Upper Limb"),
    Flashcard("Femoral nerve roots?", "L2–L4 posterior divisions.", "Lower Limb"),
    Flashcard("Sciatic nerve roots?", "L4–S3.", "Lower Limb"),
    Flashcard("Common fibular nerve landmark?", "Around the neck of the fibula.", "Lower Limb"),
    Flashcard("Gluteus maximus nerve?", "Inferior gluteal nerve.", "Lower Limb"),
    Flashcard("Phrenic nerve roots?", "C3–C5.", "Thorax"),
    Flashcard("Right lung lobes?", "Superior, middle and inferior.", "Thorax"),
    Flashcard("Heart apex?", "Mainly formed by the left ventricle.", "Thorax"),
    Flashcard("Celiac trunk supplies?", "Foregut derivatives.", "Abdomen"),
    Flashcard("Portal vein formation?", "Usually splenic vein + superior mesenteric vein.", "Abdomen"),
    Flashcard("Kidneys: anatomical compartment?", "Retroperitoneal.", "Abdomen"),
    Flashcard("CN V main facial role?", "Major general sensory nerve of the face; motor to mastication.", "Head & Neck"),
    Flashcard("CN VII main motor role?", "Muscles of facial expression.", "Head & Neck"),
    Flashcard("CN XII?", "Motor nerve to most tongue muscles.", "Head & Neck"),
    Flashcard("Pudendal nerve roots?", "S2–S4.", "Pelvis & Perineum"),
    Flashcard("Pelvic diaphragm main muscles?", "Levator ani and coccygeus.", "Pelvis & Perineum"),
    Flashcard("Spinal dorsal root function?", "Carries sensory afferent fibers.", "Neuroanatomy"),
    Flashcard("Spinal ventral root function?", "Carries motor efferent fibers.", "Neuroanatomy"),
    Flashcard("Adult spinal cord ends?", "Usually around L1–L2, with variation.", "Neuroanatomy"),
    Flashcard("Medial malleolus belongs to?", "Tibia.", "Bones & Joints"),
    Flashcard("Lateral malleolus belongs to?", "Fibula.", "Bones & Joints")
)

val imageQuestions = listOf(
    ImageQuestion("Median nerve", "A labeled upper-limb diagram points to the nerve passing through the carpal tunnel.", listOf("Median nerve","Ulnar nerve","Radial nerve","Axillary nerve"),0),
    ImageQuestion("Femoral nerve", "A diagram of the femoral triangle points to the large nerve lateral to the femoral artery.", listOf("Femoral nerve","Obturator nerve","Sciatic nerve","Tibial nerve"),0),
    ImageQuestion("Brachial artery", "A diagram of the arm points to the main artery continuing from the axillary artery.", listOf("Brachial artery","Radial artery","Ulnar artery","Subclavian artery"),0),
    ImageQuestion("Sciatic nerve", "A posterior hip diagram points to the large nerve leaving the pelvis inferior to piriformis.", listOf("Sciatic nerve","Femoral nerve","Obturator nerve","Superior gluteal nerve"),0),
    ImageQuestion("Phrenic nerve", "A thorax diagram points to the nerve descending on the fibrous pericardium toward the diaphragm.", listOf("Phrenic nerve","Vagus nerve","Intercostal nerve","Sympathetic trunk"),0),
    ImageQuestion("Aortic arch", "A thoracic diagram points to the curved part of the aorta superior to the heart.", listOf("Aortic arch","Pulmonary trunk","Descending thoracic aorta","Superior vena cava"),0),
    ImageQuestion("Portal vein", "An abdominal diagram points to the major venous channel entering the liver at the porta hepatis.", listOf("Portal vein","Inferior vena cava","Hepatic vein","Renal vein"),0),
    ImageQuestion("Internal jugular vein", "A neck diagram points to the large vein within the carotid sheath.", listOf("Internal jugular vein","External jugular vein","Subclavian vein","Facial vein"),0),
    ImageQuestion("Pudendal nerve", "A pelvic diagram points to the somatic nerve supplying the perineum.", listOf("Pudendal nerve","Femoral nerve","Sciatic nerve","Vagus nerve"),0),
    ImageQuestion("Dorsal root ganglion", "A spinal diagram points to the swelling on the dorsal root.", listOf("Dorsal root ganglion","Ventral horn","Sympathetic trunk","Ventral root"),0)
)

fun loadPrefs(context: Context): SharedPreferences =
    context.getSharedPreferences("anatomy_master", Context.MODE_PRIVATE)



@Composable
fun App() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { loadPrefs(context) }
    var screen by remember { mutableStateOf("home") }
    var selectedDetailTopic by remember { mutableStateOf<TopicDetail?>(null) }
    var selectedTopic by remember { mutableStateOf<Topic?>(null) }
    var selectedStudyName by remember { mutableStateOf("") }
    var selectedStudyItems by remember { mutableStateOf<List<String>>(emptyList()) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF2457A6))) {
        when (screen) {
            "home" -> Home(
                onTopic = { selectedTopic = it; screen = "topic" },
                onQuiz = { screen = "quiz" },
                onImages = { screen = "images" },
                onProgress = { screen = "progress" },
                onFlashcards = { screen = "flashcards" },
                onInteractive = { screen = "interactive" },
                onReview = { screen = "review" },
                onChapters = { screen = "chapters" },
                onExam = { screen = "exam" },
                onLibrary = { screen = "library" },
                onRegions = { screen = "regions" },
                onFinal = { screen = "final" }
            )
            "topic" -> selectedTopic?.let { TopicScreen(it, prefs, onBack = { screen = "home" }) }
            "quiz" -> QuizScreen(prefs, onBack = { screen = "home" })
            "images" -> ImageQuizScreen(onBack = { screen = "home" })
            "progress" -> ProgressScreen(prefs, onBack = { screen = "home" })
            "flashcards" -> FlashcardsScreen(onBack = { screen = "home" })
            "interactive" -> InteractiveAnatomyScreen(onBack = { screen = "home" })
            "review" -> SpacedReviewScreen(onBack = { screen = "home" })
            "chapters" -> ChaptersScreen(onBack = { screen = "home" })
            "exam" -> ExamModeScreen(onBack = { screen = "home" })
            "library" -> TopicLibraryScreen(
                onBack = { screen = "home" },
                onTopic = { selectedDetailTopic = it; screen = "topicDetail" }
            )
            "topicDetail" -> selectedDetailTopic?.let {
                TopicDetailScreen(it, onBack = { screen = "library" })
            }
            "regions" -> FinalRegionsScreen(
                onBack = { screen = "home" },
                onStudy = { name, items ->
                    selectedStudyName = name
                    selectedStudyItems = items
                    screen = "study"
                }
            )
            "study" -> StudyChapterScreen(selectedStudyName, selectedStudyItems, onBack = { screen = "regions" })
            "final" -> FinalDashboard(
                onBack = { screen = "home" },
                onExam = { screen = "exam" },
                onRegions = { screen = "regions" },
                onFlashcards = { screen = "flashcards" }
            )
        }
        }
    }
}

@Composable
fun Home(onTopic: (Topic) -> Unit, onQuiz: () -> Unit, onImages: () -> Unit, onProgress: () -> Unit, onFlashcards: () -> Unit, onInteractive: () -> Unit, onReview: () -> Unit, onChapters: () -> Unit, onExam: () -> Unit, onLibrary: () -> Unit, onRegions: () -> Unit, onFinal: () -> Unit) {
    val totalQuestions = mcqs.size + extraMcqs.size
    var query by remember { mutableStateOf("") }
    val filtered = topics.filter { "${it.title} ${it.region}".contains(query, true) }
    Scaffold(bottomBar = {
        NavigationBar {
            NavigationBarItem(true, {}, { }, icon={Icon(Icons.Default.Home,null)}, label={Text("Home")})
            NavigationBarItem(false, {}, onQuiz, icon={Icon(Icons.Default.Quiz,null)}, label={Text("Quiz")})
            NavigationBarItem(false, {}, onProgress, icon={Icon(Icons.Default.Star,null)}, label={Text("Progress")})
        }
    }) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(18.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            item {
                Text("Anatomy Master", fontSize=30.sp, fontWeight=FontWeight.Bold)
                Text("General Medicine • Clinical Anatomy", color=Color.Gray)
                Spacer(Modifier.height(10.dp))
                Text("📚 ${topics.size} core topics   •   ❓ $totalQuestions MCQs", fontWeight=FontWeight.SemiBold)
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),placeholder={Text("Search anatomy...")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true)
                Spacer(Modifier.height(14.dp))
                Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF1FF))) {
                    Column(Modifier.padding(18.dp)) {
                        Text("First-year style foundation",fontWeight=FontWeight.Bold,fontSize=18.sp)
                        Text("Original high-yield notes organized by region, with clinical correlations and MCQs.")
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick=onImages, modifier=Modifier.weight(1f)) {
                        Icon(Icons.Default.ImageSearch, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Image Quiz")
                    }
                    OutlinedButton(onClick=onProgress, modifier=Modifier.weight(1f)) {
                        Icon(Icons.Default.Insights, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Progress")
                    }
                }
                OutlinedButton(onClick=onFlashcards, modifier=Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Style, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Flashcards • Spaced Review")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick=onInteractive, modifier=Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.AccessibilityNew, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Interactive Anatomy")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick=onReview, modifier=Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Replay, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Today's Spaced Review")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick=onChapters, modifier=Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.MenuBook, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Anatomy Chapters")
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick=onExam, modifier=Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Quiz, null)
                    Spacer(Modifier.width(6.dp))
                    Text("20-Question Exam Mode")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick=onLibrary, modifier=Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.LocalLibrary, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Clinical Anatomy Library")
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick=onRegions, modifier=Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.AccountTree, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Core Regional Chapters")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick=onFinal, modifier=Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Dashboard, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Final Study Dashboard")
                }
                }
                Spacer(Modifier.height(8.dp))
            }
            items(filtered) { t ->
                Card(Modifier.fillMaxWidth().clickable{onTopic(t)}) {
                    Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
                        Text(iconFor(t.region),fontSize=30.sp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(t.title,fontWeight=FontWeight.Bold,fontSize=18.sp)
                            Text(t.region,color=Color.Gray)
                        }
                        Icon(Icons.Default.ChevronRight,null)
                    }
                }
            }
        }
    }
}
fun iconFor(region:String)=when(region){"Upper Limb"->"💪";"Lower Limb"->"🦵";"Thorax"->"🫁";"Abdomen"->"🫀";"Head & Neck"->"🧠";"Pelvis & Perineum"->"🩺";"Neuroanatomy"->"🧠";else->"🦴"}

@Composable
fun TopicScreen(t: Topic, prefs: SharedPreferences, onBack:()->Unit) {
    Scaffold(topBar={TopAppBar(
        title={Text(t.title)},
        navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)}},
        actions={
            val key = "fav_" + t.title
            val saved = prefs.getBoolean(key, false)
            IconButton(onClick={prefs.edit().putBoolean(key, !saved).apply()}) {
                Icon(if(saved) Icons.Default.Star else Icons.Default.StarBorder, null)
            }
        }
    )}){pad->
        Column(Modifier.fillMaxSize().padding(pad).padding(18.dp).verticalScroll(rememberScrollState())) {
            Text(t.region,color=Color(0xFF2457A6),fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text("High-Yield Anatomy",fontSize=24.sp,fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            t.facts.forEachIndexed { i, fact ->
                Row(Modifier.padding(vertical=7.dp)) {
                    Text("${i+1}. ",fontWeight=FontWeight.Bold)
                    Text(fact)
                }
            }
            Spacer(Modifier.height(14.dp))
            Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFF4F6FA))) {
                Column(Modifier.padding(16.dp)) {
                    Text("Clinical Anatomy",fontWeight=FontWeight.Bold,fontSize=18.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(t.clinical)
                }
            }
        }
    }
}

@Composable
fun QuizScreen(prefs: SharedPreferences, onBack:()->Unit) {
    var index by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf<Int?>(null) }
    var score by remember { mutableStateOf(0) }
    val allQuestions = remember { mcqs + extraMcqs }
    val q = allQuestions[index]
    val finished = index >= allQuestions.size
    if (finished) {
        Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally) {
            Text("Quiz Complete",fontSize=30.sp,fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text("Score: $score / ${allQuestions.size}",fontSize=22.sp)
            val oldBest = prefs.getInt("best_score", 0)
            if (score > oldBest) prefs.edit().putInt("best_score", score).apply()
            Text("Best score: ${maxOf(oldBest, score)} / ${allQuestions.size}", color=Color.Gray)
            Spacer(Modifier.height(20.dp))
            Button(onClick=onBack){Text("Back to Home")}
        }
        return
    }
    Scaffold(topBar={TopAppBar(title={Text("Anatomy Quiz")},navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)}})}){pad->
        Column(Modifier.fillMaxSize().padding(pad).padding(20.dp)) {
            Text("Question ${index+1} / ${allQuestions.size}",color=Color.Gray)
            Spacer(Modifier.height(12.dp))
            Text(q.question,fontSize=22.sp,fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(18.dp))
            q.options.forEachIndexed { i,opt ->
                val chosen = selected == i
                Button(
                    onClick={if(selected==null) {{selected=i; if(i==q.answer) score++}} else {{}}},
                    modifier=Modifier.fillMaxWidth().padding(vertical=4.dp),
                    colors=ButtonDefaults.buttonColors(containerColor=if(chosen) Color(0xFF2457A6) else Color(0xFFE9EDF3), contentColor=if(chosen) Color.White else Color.Black)
                ){Text("${"ABCD"[i]}. $opt")}
            }
            if(selected != null) {
                Spacer(Modifier.height(12.dp))
                Text(if(selected==q.answer) "Correct ✅" else "Incorrect ❌",fontWeight=FontWeight.Bold)
                Text(q.explanation,color=Color.Gray)
                Spacer(Modifier.height(12.dp))
                Button(onClick={selected=null;index++},modifier=Modifier.fillMaxWidth()){Text(if(index==allQuestions.lastIndex)"Finish" else "Next")}
            }
        }
    }
}


@Composable
fun ImageQuizScreen(onBack:()->Unit) {
    var index by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf<Int?>(null) }
    var score by remember { mutableStateOf(0) }

    if (index >= imageQuestions.size) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement=Arrangement.Center, horizontalAlignment=Alignment.CenterHorizontally) {
            Text("Image Quiz Complete", fontSize=28.sp, fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Text("Score: $score / ${imageQuestions.size}", fontSize=22.sp)
            Spacer(Modifier.height(20.dp))
            Button(onClick=onBack) { Text("Back to Home") }
        }
        return
    }

    val q = imageQuestions[index]
    Scaffold(topBar={TopAppBar(title={Text("Image Identification")}, navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)}})}) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(20.dp).verticalScroll(rememberScrollState())) {
            Text("Question ${index+1} / ${imageQuestions.size}", color=Color.Gray)
            Spacer(Modifier.height(12.dp))
            Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF1FF))) {
                Column(Modifier.padding(22.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                    Text("ANATOMY DIAGRAM", fontWeight=FontWeight.Bold, color=Color(0xFF2457A6))
                    Spacer(Modifier.height(14.dp))
                    Text("🫀", fontSize=62.sp)
                    Spacer(Modifier.height(10.dp))
                    Text(q.clue, fontSize=16.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
            q.options.forEachIndexed { i, opt ->
                Button(
                    onClick={if(selected==null){selected=i;if(i==q.answer)score++}},
                    modifier=Modifier.fillMaxWidth().padding(vertical=4.dp),
                    colors=ButtonDefaults.buttonColors(
                        containerColor=if(selected==i) Color(0xFF2457A6) else Color(0xFFE9EDF3),
                        contentColor=if(selected==i) Color.White else Color.Black
                    )
                ){Text("${"ABCD"[i]}. $opt")}
            }
            if(selected != null) {
                Spacer(Modifier.height(12.dp))
                Text(if(selected==q.answer) "Correct ✅" else "Incorrect ❌", fontWeight=FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Button(onClick={selected=null;index++}, modifier=Modifier.fillMaxWidth()) {
                    Text(if(index==imageQuestions.lastIndex) "Finish" else "Next")
                }
            }
        }
    }
}

@Composable
fun ProgressScreen(prefs: SharedPreferences, onBack:()->Unit) {
    val total = mcqs.size + extraMcqs.size
    val best = prefs.getInt("best_score", 0)
    val favorites = topics.count { prefs.getBoolean("fav_" + it.title, false) }
    val percent = if(total == 0) 0 else (best * 100 / total)

    Scaffold(topBar={TopAppBar(title={Text("My Progress")}, navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)}})}) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(20.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
            Text("Study Dashboard", fontSize=27.sp, fontWeight=FontWeight.Bold)
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("Best Quiz Score", fontWeight=FontWeight.Bold)
                    Text("$best / $total", fontSize=30.sp, color=Color(0xFF2457A6))
                    Text("$percent%")
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("Saved Topics", fontWeight=FontWeight.Bold)
                    Text("$favorites topics")
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("Available Study Bank", fontWeight=FontWeight.Bold)
                    Text("${topics.size} anatomy topics • $total MCQs • ${imageQuestions.size} image questions • ${flashcards.size} flashcards")
                }
            }
        }
    }
}




data class ReviewState(val dueAt: Long, val streak: Int)

@Composable
fun InteractiveAnatomyScreen(onBack:()->Unit) {
    var selected by remember { mutableStateOf("Tap a structure") }
    val labels = listOf("Clavicle", "Humerus", "Brachial plexus", "Heart", "Lungs", "Femur")
    Scaffold(topBar={
        TopAppBar(
            title={Text("Interactive Anatomy")},
            navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)}}
        )
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)) {
            Text("Tap a structure", fontSize=24.sp, fontWeight=FontWeight.Bold)
            Text("Original study schematic • educational use", color=Color.Gray)
            Spacer(Modifier.height(12.dp))
            Card(Modifier.fillMaxWidth().weight(1f)) {
                Canvas(Modifier.fillMaxSize().padding(12.dp)) {
                    val cx = size.width/2f
                    val top = size.height*0.08f
                    // Head / trunk
                    drawCircle(Color(0xFFE8C7A8), size.minDimension*0.075f, Offset(cx, top+45))
                    drawLine(Color(0xFF9AA6B2), Offset(cx, top+90), Offset(cx, top+size.height*0.55f), 22f)
                    // clavicles
                    drawLine(Color(0xFFCFD6DE), Offset(cx-120, top+125), Offset(cx, top+105), 18f)
                    drawLine(Color(0xFFCFD6DE), Offset(cx, top+105), Offset(cx+120, top+125), 18f)
                    // arms
                    drawLine(Color(0xFFE8C7A8), Offset(cx-120, top+125), Offset(cx-180, top+size.height*0.40f), 38f)
                    drawLine(Color(0xFFE8C7A8), Offset(cx+120, top+125), Offset(cx+180, top+size.height*0.40f), 38f)
                    // humeri
                    drawLine(Color(0xFFE4E8ED), Offset(cx-125, top+145), Offset(cx-175, top+size.height*0.39f), 14f)
                    drawLine(Color(0xFFE4E8ED), Offset(cx+125, top+145), Offset(cx+175, top+size.height*0.39f), 14f)
                    // lungs
                    drawCircle(Color(0xFFD6E7F7), size.minDimension*0.11f, Offset(cx-55, top+225))
                    drawCircle(Color(0xFFD6E7F7), size.minDimension*0.11f, Offset(cx+55, top+225))
                    // heart
                    drawCircle(Color(0xFFE9A5A5), size.minDimension*0.075f, Offset(cx, top+260))
                    // legs / femurs
                    drawLine(Color(0xFFE8C7A8), Offset(cx-60, top+size.height*0.55f), Offset(cx-95, top+size.height*0.90f), 48f)
                    drawLine(Color(0xFFE8C7A8), Offset(cx+60, top+size.height*0.55f), Offset(cx+95, top+size.height*0.90f), 48f)
                    drawLine(Color(0xFFE4E8ED), Offset(cx-60, top+size.height*0.55f), Offset(cx-95, top+size.height*0.90f), 18f)
                    drawLine(Color(0xFFE4E8ED), Offset(cx+60, top+size.height*0.55f), Offset(cx+95, top+size.height*0.90f), 18f)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Selected: $selected", fontSize=20.sp, fontWeight=FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                labels.take(3).forEach { label ->
                    OutlinedButton(onClick={selected=label}, modifier=Modifier.weight(1f)){Text(label, maxLines=1)}
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                labels.drop(3).forEach { label ->
                    OutlinedButton(onClick={selected=label}, modifier=Modifier.weight(1f)){Text(label, maxLines=1)}
                }
            }
        }
    }
}

@Composable
fun SpacedReviewScreen(onBack:()->Unit) {
    var index by remember { mutableStateOf(0) }
    var completed by remember { mutableStateOf(0) }
    val due = flashcards.shuffled().take(10)
    val card = due.getOrNull(index)

    Scaffold(topBar={
        TopAppBar(title={Text("Spaced Review")}, navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)}})
    }) { pad ->
        if (card == null) {
            Column(Modifier.fillMaxSize().padding(pad), verticalArrangement=Arrangement.Center, horizontalAlignment=Alignment.CenterHorizontally) {
                Text("Today's review complete", fontSize=27.sp, fontWeight=FontWeight.Bold)
                Text("$completed cards reviewed", fontSize=20.sp)
                Spacer(Modifier.height(18.dp))
                Button(onClick=onBack){Text("Back")}
            }
        } else {
            Column(Modifier.fillMaxSize().padding(pad).padding(20.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                Text("Daily review • ${index+1}/10", color=Color.Gray)
                Spacer(Modifier.height(20.dp))
                Card(Modifier.fillMaxWidth().height(280.dp)) {
                    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement=Arrangement.Center, horizontalAlignment=Alignment.CenterHorizontally) {
                        Text(card.region, color=Color(0xFF2457A6), fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(18.dp))
                        Text(card.front, fontSize=25.sp, fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(15.dp))
                        Text(card.back, fontSize=19.sp)
                    }
                }
                Spacer(Modifier.height(18.dp))
                Text("How well did you remember it?")
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick={completed++;index++}, modifier=Modifier.weight(1f)){Text("Again")}
                    OutlinedButton(onClick={completed++;index++}, modifier=Modifier.weight(1f)){Text("Hard")}
                    Button(onClick={completed++;index++}, modifier=Modifier.weight(1f)){Text("Good")}
                }
                Spacer(Modifier.height(8.dp))
                Text("Easy = increase the interval next time", color=Color.Gray, fontSize=13.sp)
            }
        }
    }
}


data class Chapter(val title: String, val subtitle: String, val topics: List<String>)

val chapters = listOf(
    Chapter("Upper Limb", "Shoulder to hand", listOf("Brachial Plexus","Axilla","Arm","Cubital Fossa","Forearm","Carpal Tunnel")),
    Chapter("Lower Limb", "Hip to foot", listOf("Lumbar Plexus","Femoral Triangle","Gluteal Region","Popliteal Fossa","Leg","Ankle")),
    Chapter("Thorax", "Thoracic wall and organs", listOf("Thoracic Wall","Intercostal Spaces","Pleura","Lungs","Mediastinum","Heart")),
    Chapter("Abdomen", "Abdominal wall and viscera", listOf("Anterior Abdominal Wall","Inguinal Canal","Peritoneum","Stomach","Liver","Portal System")),
    Chapter("Head & Neck", "Cranial nerves and regions", listOf("Cranial Nerves","Cavernous Sinus","Neck Triangles","Pharynx","Larynx","Face")),
    Chapter("Pelvis & Perineum", "Pelvic viscera and floor", listOf("Pelvic Floor","Perineum","Pudendal Canal","Bladder","Rectum","Reproductive Organs")),
    Chapter("Neuroanatomy", "Spinal cord and pathways", listOf("Spinal Cord","Roots","Dermatomes","Ascending Tracts","Descending Tracts","Reflexes"))
)

@Composable
fun ChaptersScreen(onBack:()->Unit) {
    var selected by remember { mutableStateOf<Chapter?>(null) }
    Scaffold(topBar={
        TopAppBar(title={Text("Anatomy Chapters")}, navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)}})
    }) { pad ->
        if (selected == null) {
            LazyColumn(Modifier.fillMaxSize().padding(pad).padding(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
                items(chapters) { ch ->
                    Card(onClick={selected=ch}, modifier=Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp)) {
                            Text(ch.title, fontSize=23.sp, fontWeight=FontWeight.Bold)
                            Text(ch.subtitle, color=Color.Gray)
                            Spacer(Modifier.height(6.dp))
                            Text("${ch.topics.size} core topics")
                        }
                    }
                }
            }
        } else {
            Column(Modifier.fillMaxSize().padding(pad).padding(18.dp)) {
                Text(selected!!.title, fontSize=28.sp, fontWeight=FontWeight.Bold)
                Text(selected!!.subtitle, color=Color.Gray)
                Spacer(Modifier.height(15.dp))
                selected!!.topics.forEachIndexed { i, t ->
                    Card(Modifier.fillMaxWidth().padding(vertical=4.dp)) {
                        Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
                            Text("${i+1}", fontWeight=FontWeight.Bold, modifier=Modifier.width(30.dp))
                            Column {
                                Text(t, fontSize=18.sp, fontWeight=FontWeight.SemiBold)
                                Text("Clinical anatomy study topic", color=Color.Gray, fontSize=13.sp)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick={selected=null}, modifier=Modifier.fillMaxWidth()){Text("Back to Chapters")}
            }
        }
    }
}

@Composable
fun ExamModeScreen(onBack:()->Unit) {
    var index by remember { mutableStateOf(0) }
    var score by remember { mutableStateOf(0) }
    var chosen by remember { mutableStateOf<Int?>(null) }
    val bank = topics.flatMap { it.mcqs }.shuffled().take(20)
    val q = bank.getOrNull(index)

    Scaffold(topBar={
        TopAppBar(title={Text("Exam Mode • 20 Questions")}, navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)}})
    }) { pad ->
        if (q == null) {
            Column(Modifier.fillMaxSize().padding(pad), verticalArrangement=Arrangement.Center, horizontalAlignment=Alignment.CenterHorizontally) {
                Text("Exam Finished", fontSize=30.sp, fontWeight=FontWeight.Bold)
                Text("Score: $score / 20", fontSize=24.sp)
                Spacer(Modifier.height(20.dp))
                Button(onClick=onBack){Text("Back to Home")}
            }
        } else {
            Column(Modifier.fillMaxSize().padding(pad).padding(18.dp)) {
                Text("Question ${index+1} / 20", color=Color.Gray)
                Spacer(Modifier.height(12.dp))
                Text(q.question, fontSize=22.sp, fontWeight=FontWeight.Bold)
                Spacer(Modifier.height(18.dp))
                q.options.forEachIndexed { i, option ->
                    val selected = chosen == i
                    Button(
                        onClick={ if(chosen==null) chosen=i },
                        modifier=Modifier.fillMaxWidth().padding(vertical=4.dp)
                    ){ Text("${('A'.code+i).toChar()}. $option") }
                }
                if (chosen != null) {
                    Spacer(Modifier.height(10.dp))
                    val correct = chosen == q.answer
                    Text(if(correct) "Correct ✓" else "Incorrect ✗  Correct answer: ${('A'.code+q.answer).toChar()}",
                        fontSize=18.sp, fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick={
                        if(correct) score++
                        index++
                        chosen=null
                    }, modifier=Modifier.fillMaxWidth()){Text(if(index==19) "Finish" else "Next Question")}
                }
            }
        }
    }
}


data class TopicDetail(val title: String, val region: String, val overview: String, val clinical: String, val keyPoints: List<String>)

val detailedTopics = listOf(
    TopicDetail("Brachial Plexus","Upper Limb","Formed by anterior rami C5–T1 and organized as roots, trunks, divisions, cords and terminal branches.","Injuries can produce characteristic motor and sensory deficits depending on the level involved.",listOf("Roots: C5–T1","Trunks: superior, middle, inferior","Cords named around the axillary artery","Major terminal nerves: musculocutaneous, median, ulnar, axillary, radial")),
    TopicDetail("Inguinal Canal","Abdomen","An oblique passage through the lower anterior abdominal wall.","Clinically important because of indirect and direct inguinal hernias.",listOf("Deep ring is lateral to inferior epigastric vessels","Superficial ring lies in external oblique aponeurosis","Inguinal ligament forms the floor")),
    TopicDetail("Heart","Thorax","A muscular pump located in the middle mediastinum with four chambers and associated great vessels.","Coronary artery disease, valvular disease and conduction disorders are major clinical correlations.",listOf("Apex mainly left ventricle","Right ventricle forms much of anterior surface","Coronary arteries arise from ascending aorta")),
    TopicDetail("Femoral Triangle","Lower Limb","A triangular region at the upper anterior thigh containing major neurovascular structures.","Important landmark for vascular access and understanding femoral hernias.",listOf("Bounded superiorly by inguinal ligament","Femoral nerve is lateral to femoral artery","Femoral vein lies medial to artery")),
    TopicDetail("Cranial Nerves","Head & Neck","Twelve paired cranial nerves emerge from the brain or brainstem and carry sensory, motor or mixed fibers.","Cranial nerve examination helps localize neurological lesions.",listOf("I: olfaction","II: vision","III, IV, VI: eye movements","V: facial sensation and mastication","VII: facial expression","VIII: hearing and balance","IX, X: pharyngeal functions","XI: SCM/trapezius","XII: tongue movement")),
    TopicDetail("Spinal Cord","Neuroanatomy","The spinal cord is a central nervous system structure continuous with the medulla and organized into segments.","Lesion level and tract involvement determine neurological deficits.",listOf("Gray matter is central","White matter surrounds gray matter","Dorsal roots are sensory","Ventral roots are motor","Adult cord commonly ends around L1–L2"))
)

@Composable
fun TopicDetailScreen(topic: TopicDetail, onBack:()->Unit) {
    Scaffold(topBar={
        TopAppBar(title={Text(topic.title)}, navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)}})
    }) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(18.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
            item {
                Text(topic.region, color=Color(0xFF2457A6), fontWeight=FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Text(topic.overview, fontSize=18.sp)
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Key Anatomy", fontSize=21.sp, fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        topic.keyPoints.forEach { p ->
                            Row(Modifier.padding(vertical=5.dp)) {
                                Text("• ", fontWeight=FontWeight.Bold)
                                Text(p)
                            }
                        }
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Clinical Correlation", fontSize=21.sp, fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(topic.clinical)
                    }
                }
            }
            item {
                Text("Study note: content is original educational wording based on standard clinical-anatomy concepts; it is not copied verbatim from Snell.", color=Color.Gray, fontSize=13.sp)
            }
        }
    }
}

@Composable
fun TopicLibraryScreen(onBack:()->Unit, onTopic:(TopicDetail)->Unit) {
    Scaffold(topBar={
        TopAppBar(title={Text("Clinical Anatomy Library")}, navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)}})
    }) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(14.dp), verticalArrangement=Arrangement.spacedBy(9.dp)) {
            items(detailedTopics) { t ->
                Card(onClick={onTopic(t)}, modifier=Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(17.dp)) {
                        Text(t.title, fontSize=21.sp, fontWeight=FontWeight.Bold)
                        Text(t.region, color=Color.Gray)
                        Spacer(Modifier.height(5.dp))
                        Text(t.overview, maxLines=2)
                    }
                }
            }
        }
    }
}


val upperLimbStudy = listOf(
    "Bones: clavicle, scapula, humerus, radius, ulna and hand",
    "Axilla: boundaries, contents and clinical relevance",
    "Brachial plexus: roots, trunks, divisions, cords and terminal branches",
    "Shoulder: rotator cuff and major movements",
    "Arm: anterior and posterior compartments",
    "Cubital fossa: boundaries and neurovascular contents",
    "Forearm: flexor/pronator and extensor/supinator compartments",
    "Wrist and hand: carpal tunnel and intrinsic muscles"
)

val lowerLimbStudy = listOf(
    "Bones: hip bone, femur, tibia, fibula and foot",
    "Gluteal region: muscles, vessels and nerves",
    "Femoral triangle: boundaries and contents",
    "Thigh: anterior, medial and posterior compartments",
    "Knee: cruciate ligaments, menisci and popliteal fossa",
    "Leg: anterior, lateral and posterior compartments",
    "Ankle: retinacula, tendons and neurovascular structures",
    "Foot: arches and intrinsic muscles"
)

val thoraxStudy = listOf(
    "Thoracic wall: ribs, sternum and intercostal spaces",
    "Intercostal neurovascular bundle and clinical procedures",
    "Pleura and pleural recesses",
    "Lungs: lobes, fissures, surfaces and bronchopulmonary segments",
    "Mediastinum and major vessels",
    "Heart: chambers, valves, coronary circulation and conduction system"
)

@Composable
fun StudyChapterScreen(title:String, items:List<String>, onBack:()->Unit) {
    Scaffold(topBar={
        TopAppBar(title={Text(title)}, navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)}})
    }) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            item {
                Text("Core study checklist", fontSize=25.sp, fontWeight=FontWeight.Bold)
                Text("Use this as a structured revision path.", color=Color.Gray)
                Spacer(Modifier.height(8.dp))
            }
            items.forEachIndexed { i, item ->
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(16.dp), verticalAlignment=Alignment.Top) {
                            Text("${i+1}", fontWeight=FontWeight.Bold, modifier=Modifier.width(30.dp))
                            Text(item, fontSize=17.sp)
                        }
                    }
                }
            }
            item {
                Spacer(Modifier.height(10.dp))
                Text("Clinical anatomy focus", fontSize=20.sp, fontWeight=FontWeight.Bold)
                Text("Revise relations, nerve supply, blood supply, movements, common injuries and important surface landmarks.", color=Color.Gray)
            }
        }
    }
}

@Composable
fun RegionalHubScreen(onBack:()->Unit, onUpper:()->Unit, onLower:()->Unit, onThorax:()->Unit) {
    Scaffold(topBar={
        TopAppBar(title={Text("Core Regional Anatomy")}, navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)}})
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            Text("Focused chapters", fontSize=27.sp, fontWeight=FontWeight.Bold)
            Text("Start with the three expanded regions in v8.", color=Color.Gray)
            Button(onClick=onUpper, modifier=Modifier.fillMaxWidth()) { Text("Upper Limb") }
            Button(onClick=onLower, modifier=Modifier.fillMaxWidth()) { Text("Lower Limb") }
            Button(onClick=onThorax, modifier=Modifier.fillMaxWidth()) { Text("Thorax") }
        }
    }
}


val abdomenStudy = listOf(
    "Anterior abdominal wall: layers, vessels and nerves",
    "Inguinal region: inguinal canal, rings and hernias",
    "Peritoneum: folds, ligaments, omenta and spaces",
    "Stomach: parts, relations, blood supply and lymphatics",
    "Duodenum and pancreas: relations and vascular supply",
    "Liver and biliary tree: surfaces, porta hepatis and ducts",
    "Portal venous system and portosystemic anastomoses",
    "Kidneys and ureters: relations and major clinical landmarks"
)

val headNeckStudy = listOf(
    "Scalp and face: layers, vessels and sensory innervation",
    "Neck triangles and deep cervical fascia",
    "Cranial nerves: functional components and examination",
    "Orbit: walls, contents and extraocular muscles",
    "Pharynx and larynx: muscles, nerves and spaces",
    "Carotid sheath and major cervical vessels",
    "Cavernous sinus and related cranial nerves",
    "Clinical surface anatomy of head and neck"
)

val pelvisStudy = listOf(
    "Pelvic walls and pelvic diaphragm",
    "Perineum: triangles, fascia and spaces",
    "Pudendal nerve and internal pudendal vessels",
    "Urinary bladder and urethra",
    "Rectum and anal canal",
    "Pelvic viscera and major neurovascular relations",
    "Pelvic floor support and clinical correlations",
    "Reproductive anatomy: major regional relations"
)

val neuroStudy = listOf(
    "Spinal cord: segments, enlargements and termination",
    "Spinal roots, dorsal root ganglia and peripheral nerves",
    "Dermatomes and myotomes",
    "Ascending sensory pathways",
    "Descending motor pathways",
    "Reflex arcs and clinical localization",
    "Brainstem overview and cranial nerve nuclei",
    "Basic autonomic anatomy"
)

@Composable
fun FinalRegionsScreen(onBack:()->Unit, onStudy:(String,List<String>)->Unit) {
    val regions = listOf(
        "Upper Limb" to upperLimbStudy,
        "Lower Limb" to lowerLimbStudy,
        "Thorax" to thoraxStudy,
        "Abdomen" to abdomenStudy,
        "Head & Neck" to headNeckStudy,
        "Pelvis & Perineum" to pelvisStudy,
        "Neuroanatomy" to neuroStudy
    )
    Scaffold(topBar={
        TopAppBar(title={Text("Complete Regional Anatomy")}, navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)}})
    }) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(14.dp), verticalArrangement=Arrangement.spacedBy(9.dp)) {
            item {
                Text("General Medicine • Clinical Anatomy", fontSize=22.sp, fontWeight=FontWeight.Bold)
                Text("Complete regional revision map", color=Color.Gray)
                Spacer(Modifier.height(5.dp))
            }
            items(regions) { pair ->
                Card(onClick={onStudy(pair.first,pair.second)}, modifier=Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(17.dp)) {
                        Text(pair.first, fontSize=21.sp, fontWeight=FontWeight.Bold)
                        Text("${pair.second.size} core study points", color=Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
fun FinalDashboard(onBack:()->Unit, onExam:()->Unit, onRegions:()->Unit, onFlashcards:()->Unit) {
    Scaffold(topBar={
        TopAppBar(title={Text("Final Study Dashboard")}, navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)}})
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(18.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Text("Anatomy Master", fontSize=30.sp, fontWeight=FontWeight.Bold)
            Text("General Medicine • Clinical Anatomy", color=Color.Gray)
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("Study Bank", fontSize=21.sp, fontWeight=FontWeight.Bold)
                    Text("${topics.size} topic records")
                    Text("${mcqs.size + extraMcqs.size} MCQs")
                    Text("${flashcards.size} flashcards")
                    Text("7 complete regional chapters")
                }
            }
            Button(onClick=onRegions, modifier=Modifier.fillMaxWidth()){Text("Regional Anatomy")}
            Button(onClick=onExam, modifier=Modifier.fillMaxWidth()){Text("20-Question Exam")}
            OutlinedButton(onClick=onFlashcards, modifier=Modifier.fillMaxWidth()){Text("Flashcards")}
            Text("Use the app as a revision companion; verify high-stakes clinical details against your course textbook and teaching materials.", color=Color.Gray, fontSize=13.sp)
        }
    }
}

@Composable
fun FlashcardsScreen(onBack:()->Unit) {
    var index by remember { mutableStateOf(0) }
    var revealed by remember { mutableStateOf(false) }
    var known by remember { mutableStateOf(0) }

    if (index >= flashcards.size) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement=Arrangement.Center, horizontalAlignment=Alignment.CenterHorizontally) {
            Text("Flashcards Complete", fontSize=28.sp, fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Text("Marked known: $known / ${flashcards.size}", fontSize=21.sp)
            Spacer(Modifier.height(20.dp))
            Button(onClick=onBack){ Text("Back to Home") }
        }
        return
    }

    val card = flashcards[index]
    Scaffold(topBar={TopAppBar(title={Text("Flashcards")}, navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)}})}) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(20.dp), horizontalAlignment=Alignment.CenterHorizontally) {
            Text("${index+1} / ${flashcards.size}", color=Color.Gray)
            Spacer(Modifier.height(20.dp))
            Card(Modifier.fillMaxWidth().height(300.dp), colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF1FF))) {
                Column(Modifier.fillMaxSize().padding(25.dp), verticalArrangement=Arrangement.Center, horizontalAlignment=Alignment.CenterHorizontally) {
                    Text(card.region, color=Color(0xFF2457A6), fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(18.dp))
                    Text(if(revealed) card.back else card.front, fontSize=25.sp, fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(18.dp))
                    Text(if(revealed) "Answer" else "Tap Reveal", color=Color.Gray)
                }
            }
            Spacer(Modifier.height(18.dp))
            if(!revealed) {
                Button(onClick={revealed=true}, modifier=Modifier.fillMaxWidth()){Text("Reveal Answer")}
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick={revealed=false;index++}, modifier=Modifier.weight(1f)){Text("Review Again")}
                    Button(onClick={known++;revealed=false;index++}, modifier=Modifier.weight(1f)){Text("I Know It")}
                }
            }
        }
    }
}


class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}
