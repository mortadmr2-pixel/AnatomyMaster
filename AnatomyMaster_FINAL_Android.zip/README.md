# Anatomy Master — Final Edition

Android anatomy revision app for General Medicine students.

## Final feature set
- Complete regional anatomy map:
  - Upper Limb
  - Lower Limb
  - Thorax
  - Abdomen
  - Head & Neck
  - Pelvis & Perineum
  - Neuroanatomy
- Structured study checklists for every region.
- Clinical Anatomy Library with topic-detail pages.
- 20-question Exam Mode with scoring.
- 75+ MCQs and explanations.
- Flashcards and daily review.
- Interactive anatomy schematic.
- Image-identification quiz.
- Favorites and Progress.
- Offline-first Material 3 interface.
- Final Study Dashboard.

## Important
This project is an educational study companion. Its wording is original and organized around standard clinical-anatomy concepts; it is not a verbatim copy of Snell. For exams and clinical decisions, use your official course material/textbook as the authority.

## Future engineering upgrades
A true 3D anatomy viewer and licensed high-resolution anatomy plates require compatible 3D/licensed assets and are intentionally not represented here as if they were already implemented.
